@echo off
echo 1. Menginstal dependensi Capacitor...
call npm install
echo 2. Menambahkan platform Android...
call npx cap add android
call npx cap sync android
echo 3. Membangun file APK debug...
cd android
call gradlew.bat assembleDebug
echo Selesai! File APK tersedia di: android\app\build\outputs\apk\debug\app-debug.apk
pause
