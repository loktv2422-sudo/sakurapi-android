#!/usr/bin/env bash
set -e
echo "1. Menginstal dependensi Capacitor..."
npm install
echo "2. Menambahkan platform Android..."
npx cap add android || true
npx cap sync android
echo "3. Membangun file APK debug..."
cd android
./gradlew assembleDebug
echo "Selesai! File APK tersedia di: android/app/build/outputs/apk/debug/app-debug.apk"
